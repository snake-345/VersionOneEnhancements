﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'sv', {
	copy: 'Copyright &copy; $1. Alla rättigheter reserverade.',
	dlgTitle: 'Om CKEditor',
	help: 'Se $1 för hjälp.',
	moreInfo: 'För information av licensiering besök vår hemsida:',
	title: 'Om CKEditor',
	userGuide: 'CKEditor User\'s Guide'
} );
