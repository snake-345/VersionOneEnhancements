﻿/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'de-ch', {
	copy: 'Copyright &copy; $1. Alle Rechte vorbehalten.',
	dlgTitle: 'Über CKEditor',
	help: 'Prüfen Sie $1 für Hilfe.',
	moreInfo: 'Für Informationen über unsere Lizenzbestimmungen besuchen sie bitte unsere Webseite:',
	title: 'Über CKEditor',
	userGuide: 'CKEditor Benutzerhandbuch'
} );
